This git repository is a pure example.

Usage
=====
This repository can be explored using ignitron, example usage can be seen below:

```sh

$ # Find duplicates
$ ignitron -b 5062e9d552e48f3f2bbe8a0ef14f73efc3277a15 -p 364b0d127ecb4632d1819e637c4bfd6ed01657a6 | tail -n 1 | jq
# # Find similar methods
$ ignitron -b 58ea852b42ac464faf61db514aecf01c8b4cccaa -p 5062e9d552e48f3f2bbe8a0ef14f73efc3277a15 | tail -n 1 | jq

```

Present commits
===============

commit 364b0d127ecb4632d1819e637c4bfd6ed01657a6 (HEAD -> main)
    Add duplicate test
commit 5062e9d552e48f3f2bbe8a0ef14f73efc3277a15
    Add tests for last nodes
commit 58ea852b42ac464faf61db514aecf01c8b4cccaa
    Initial Commit
